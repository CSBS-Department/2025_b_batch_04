vowels=['a','e','i','o','u'] 
string="madam" 
count=0
for i in  vowels:
    for j in string:
        if i==j:
            count=count+1  
no_of_vowels=count
no_of_consonants=len(string)-count
print(no_of_vowels) 
print(no_of_consonants)