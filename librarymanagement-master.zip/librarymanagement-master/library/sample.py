vowels=['a','e','i','o','u']
for i in  vowels:
    print(i)